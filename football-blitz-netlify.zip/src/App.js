import React from 'react';
import FootballBlitz from './components/FootballBlitz';

function App() {
  return (
    <div className="App">
      <FootballBlitz />
    </div>
  );
}

export default App;
