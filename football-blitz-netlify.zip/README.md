# Football Blitz

React-based American football game ready for Netlify deployment.